const mongoose = require('mongoose');

        const userSchema = new mongoose.Schema({
          name: { type: String, required:true},
          surname: { type: String, required:true},
          email:  { type: String, required:true,unique:true},
          password: { type: String, required:true},
          telefon:{ type: String, required:true,unique:true},
          //exchange:{  type: Array},
          order: [
            {
              order: {type: Boolean, required: false},
              name: {type: String, required: false},
              address: {type: String, required: false},
              phone: {type: String, required: false},
              ean: {type: String, required: false},
              customerprice: {type: String, required: false},
              customerpiece: {type: String, required: false},
              price: {type: String, required: false},
              date: {
                type: Date,
                default: Date.now
               }   
            }], 

          soru: [
            {
              _id: false,
              soru: {type: String, required: false},
              sorukodu: {type: String, required: false}
            }], 
          sorutek: [
              {
                _id: false,
                soru: {type: String, required: false},
                cevap: {type: String, required: false},
                sorukodu: {type: String, required: false}
              }],         
          bearertoken:String,
          role: String,
          token: String,
          password_link: String,
          status: Boolean,
          code: String,
          ip: String,
           date: {
             type: Date,
             default: Date.now
            },


           }) 
        
         module.exports = mongoose.model('Users', userSchema);
 