
var membersRoute=require('./controlRoute');
var adminRoute=require('./adminRoute');
var homeRoute=require('./homeRoute');
var apiRoute=require('./apiRoute');
var swgaRoute=require('./swgaRoute');

module.exports=function(app){
    
   app.use('/admin',adminRoute)    
  app.use('/control',membersRoute);
  app.use('/',homeRoute);

    app.use('/api/v1',apiRoute)    
    app.use('/swga',swgaRoute)    

}



