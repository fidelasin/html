var express=require('express');
var router=express.Router();
const rateLimit = require('express-rate-limit')
const checkAuth = require('../middleware/token');



const limiter = rateLimit({
 windowMs: 2000,
 max: 1000,
 message: {
    limiter: true,
    type: "error",
    message: 'Çok fazla deneme beklemeniz gerekli'
  }

})

var ctrl=require('../controllers/apiController');





router.post('/userlogin/',ctrl.login)
router.get('/userget/:url',checkAuth,ctrl.userGetDetay)
router.post('/sorusor',checkAuth,ctrl.sorusor)
router.post('/sorusortek',checkAuth,ctrl.sorusortek)

router.post('/products/add',checkAuth,ctrl.productsAdd)
router.get('/products/getall',checkAuth,ctrl.productGetAll)
router.get('/products/get/:ean',checkAuth,ctrl.productGet)
router.get('/products/getstock/:ean',checkAuth,ctrl.productGetStock)
router.get('/products/delete/:ean',checkAuth,ctrl.productDelete)

router.post('/order/create',checkAuth,ctrl.orderCreate)
router.get('/order/getall',checkAuth,ctrl.orderGetAll)
router.get('/order/get/:orderid',checkAuth,ctrl.orderGetId)
router.get('/order/ordercancel/:orderid',checkAuth,ctrl.orderCancel)

//router.post('/login',ctrl.loginPost)

router.post('/signup',limiter,ctrl.signup)

router.post('/verifity',ctrl.verifity)

//router.post('/forget',ctrl.forgetPost)

//router.post('/newpassword',ctrl.newpasswordPost)

//router.get('/cikis',controller.cikis);

module.exports=router; 