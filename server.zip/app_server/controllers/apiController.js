const mongoose = require('mongoose');
const url = require("url");

const User =require('../models/user');
const Products =require('../models/products');
const dotenv = require('dotenv');
dotenv.config();
const secret_key = process.env.secret_key;

const { Configuration, OpenAIApi } = require("openai");

const configuration = new Configuration({
  apiKey: process.env.OPENAI_API_KEY,
});
const openai = new OpenAIApi(configuration);

//const addMonths = require('addmonths');
//const { json } = require('body-parser');
//const store=require('store')
const jwt =require('jsonwebtoken')
const redis=require('redis');
const client=redis.createClient();

module.exports.productGetAll =async function(req,res){

const queryObject = url.parse(req.url,true).query;
    const  start=Number(queryObject.start);
    const length=Number(queryObject.length);
    var draw=queryObject["draw"];
    var searchValue=queryObject["search[value]"];

    
      let countData="0";


   const bearertoken = req.headers.authorization.split(" ")[1];

   
   User.findOne( {"bearertoken":bearertoken },{},{ },async function(err, users) {
    if(err) return await  res.json(JSON.parse('{"mesaj":"Hata"}'));

    if(users===null) { 
      return await res.json(JSON.parse('{"mesaj":"Token Hatalı"}'));
    }
   } );

 let degerJson={};
 let deger=[];
   degerJson["__v"]=0;
  deger.push(degerJson);

  Products.find( { 
    $and : deger,
    $or: [{brand:{ $regex: '.*' + searchValue + '.*' }},{title:{ $regex: '.*' + searchValue + '.*' }},{description:{ $regex: '.*' + searchValue + '.*' }},{ean:{ $regex: '.*' + searchValue + '.*' }},{gtin:{ $regex: '.*' + searchValue + '.*' }}]

   },{},function(err, users) {
    countData = users.length;
   });


     Products.find( { 
      $and : deger,
      $or: [{brand:{ $regex: '.*' + searchValue + '.*' }},{title:{ $regex: '.*' + searchValue + '.*' }},{description:{ $regex: '.*' + searchValue + '.*' }},{ean:{ $regex: '.*' + searchValue + '.*' }},{gtin:{ $regex: '.*' + searchValue + '.*' }}]

     },{},{ 
       skip: start, 
       limit: length
     }, function(err, users) {
     var userMapBirlestir = [];
     var userMapTek = {};
     sirasi=start;
     
     users.forEach(function(user) {
       
       sirasi++;
       userMapTek = {};
       userMapTek["_id"] = user._id;
       userMapTek["sira"] = sirasi;
       userMapTek["title"] = user.title;
       userMapTek["brand"] = user.brand;
       userMapTek["price"] = user.price;
       userMapTek["ean"] = user.ean;
       userMapTek["gtin"] = user.gtin;
       userMapTek["stock"] = user.stock;
       userMapBirlestir.push(userMapTek);
       
     });

   const  userMap = {
    "draw":draw,
   "recordsTotal": countData,
   "recordsFiltered": countData,"data":userMapBirlestir};
   res.json(userMap);   
  });

 }

module.exports.productGet =async function(req,res){
   var ean =req.params.ean

   const bearertoken = req.headers.authorization.split(" ")[1];
    User.findOne( {"bearertoken":bearertoken },{},{ },async function(err, users) {
     if(err) return await res.json('{"mesaj":"hata"}');  
 
     if(users===null) { 
       return await res.json(JSON.parse('{"mesaj":"Token Hatalı"}'));
     }

     Products.findOne( {"ean":ean },{},{ },async (err, product)=>  {

      if(product ===null) {
        return res.json(JSON.parse('{"mesaj":"Urun bulunamadı"}'));
      }
      return res.json(product);
      } );
    } );
  }

module.exports.productGetStock =async function(req,res){
    var ean =req.params.ean
 
    const bearertoken = req.headers.authorization.split(" ")[1];
     User.findOne( {"bearertoken":bearertoken },{},{ },async function(err, users) {
      if(err) return await res.json('{"mesaj":"hata"}');  
  
      if(users===null) { 
        return await res.json(JSON.parse('{"mesaj":"Token Hatalı"}'));
      }
 
      Products.findOne( {"ean":ean },{},{ },async (err, product)=>  {
 
       if(product ===null) {
         return res.json(JSON.parse('{"mesaj":"Urun bulunamadı"}'));
       }
       return res.json(JSON.parse('{"stock":'+product.stock+'}'));
       } );
     } );
   }



module.exports.productDelete =async function(req,res){
  var ean =req.params.ean
  const role=req.userData.mrole
   console.log(role)
   if(role !== "admin")
   return await res.json(JSON.parse('{"mesaj":"Yetkisiz erisim" }'))

  const bearertoken = req.headers.authorization.split(" ")[1];
   User.findOne( {"bearertoken":bearertoken },{},{ },async function(err, users) {
    if(err) return await res.json(JSON.parse('{"mesaj":"hata" }'))

    if(users===null) { 
      return await res.json(JSON.parse('{"mesaj":"Token Hatalı"}'));
    }

    Products.findOne( {"ean":ean },{},{ },async (err, product)=>  {
      if(product ===null) {
       return res.json(JSON.parse('{"mesaj":"Urun bulunamadı"}'));
     }

     Products.findOneAndDelete({"ean":ean },{},async (err, product)=>  {
      return await res.json(JSON.parse('{"mesaj":"basarili" }'))
     }
      )
     
     } );

     
     
   } );
 }


module.exports.productsAdd=async function(req,res){ 

  const role=req.userData.mrole
  if(role !== "admin")
  return await res.json(JSON.parse('{"mesaj":"Yetkisiz erisim" }'))

  const bearertoken = req.headers.authorization.split(" ")[1];
  const queryObject = req.body;
  const title=queryObject.title;
  const description=queryObject.description;
  const brand=queryObject.brand;
  const weight=queryObject.weight;
  const itemModelNumber=queryObject.itemModelNumber;
  const size=queryObject.size;
  const numberOfİtem=queryObject.numberOfİtem;
  const quantity=queryObject.quantity;
  const price=queryObject.price;
  const batteriesRequired=queryObject.batteriesRequired;
  const itemWeight=queryObject.itemWeight;
  const gtin=queryObject.gtin;
  const ean=queryObject.ean;
  const added=queryObject.added;
  const stock=queryObject.stock;
  const color=queryObject.color;
  const productDimensions=queryObject.productDimensions;
  const material=queryObject.material;
  const type=queryObject.type;
  const pictures=queryObject.pictures;
  const video=queryObject.video;
  const status=queryObject.status;
    User.findOne( {"bearertoken":bearertoken },{},{ },async (err, users)=>  {
    if(err) return res.json(JSON.parse('{"mesaj":"hata"}'))  
    if(users===null) { 
      return res.json(JSON.parse('{"mesaj":"Token Hatalı"}'));
    }

    Products.findOne( {"ean":ean },{},{ },async (err, product)=>  {

      if(product !==null) {
        return res.json(JSON.parse('{"mesaj":"Ekli"}'));
      }
      else
      {
                  var newProduct=new Products({
                    title: title,
                    description: description,
                    brand: brand,
                    weight: weight,
                    itemModelNumber: itemModelNumber,
                    size: size,
                    numberOfİtem: numberOfİtem,
                    quantity: quantity,
                    price: price,
                    batteriesRequired: batteriesRequired,
                    itemWeight: itemWeight,
                    gtin: gtin,
                    ean: ean,
                    added: added,
                    stock: stock,
                    color: color,
                    productDimensions: productDimensions,
                    material: material,
                    type: type,
                    pictures: pictures,
                    video: video,
                    status:true
                  });
                  newProduct.save(function(err,product){
                  if(err)
                  {
                    console.log(err);
                    return res.json(JSON.parse('{"mesaj":'+err+'}'));
                  }else{
                    return res.json(product);
                  }
                }); 
        }
      });
    });
}


module.exports.orderCreate =async function(req,res){
  console.log(req.body)
  ean =req.body.ean
  customerprice =req.body.price
  customerpiece =req.body.piece
  customername =req.body.name
  address =req.body.address
  phone =req.body.phone
 // var ean =req.params.ean
 // var customerprice =req.query.price
 // var customerpiece =req.query.piece
  const bearertoken = req.headers.authorization.split(" ")[1];

   User.findOne( {"bearertoken":bearertoken },{},{ },async function(err, user) {
    if(err) return await res.json('{"mesaj":"hata"}');  

    if(user===null) { 
      return await res.json(JSON.parse('{"mesaj":"Token Hatalı"}'));
    }

    Products.findOne( {"ean":ean },{},{ },async (err, product)=>  {

     if(product ===null) {
       return res.json(JSON.parse('{"mesaj":"Urun bulunamadı"}'));
     }
     
     price=product.price
     stock=product.stock
     console.log(stock);
     console.log(stock);
     console.log(customerpiece);
     if(stock< customerpiece ){
      return res.json(JSON.parse('{"mesaj":"'+stock+' adet urun mevcut"}'));
     }

     const newstock=stock-customerpiece

     


     await User.findOneAndUpdate({"bearertoken":bearertoken}, { $push:{ order :{order:true,name:customername,address:address,phone:phone,ean:ean,customerprice:customerprice,price:price,customerpiece:customerpiece}}  },{upsert:true});
     await Products.findOneAndUpdate({"ean":ean}, { $set:{ "stock" :newstock}  });  
       

     return res.json(JSON.parse('{"mesaj":"ok"}'));
     } );
   } );
 }

 module.exports.orderGetId =async function(req,res){
  const orderid =req.params.orderid
  console.log("orderid"+orderid)
  const bearertoken = req.headers.authorization.split(" ")[1];

   User.findOne( { "bearertoken":bearertoken ,"order._id":orderid },{},{ },async function(err, users) {
    if(err) return await res.json('{"mesaj":"hata"}');  

    if(users===null) { 
      return await res.json(JSON.parse('{"mesaj":"Token Hatalı"}'));
    }
     users.order.forEach(async element => {
        if(element._id == orderid)
        {
          console.log(element)
          return  await res.json(element);
        }
    }); 
   } );
 }


 module.exports.orderCancel =async function(req,res){
  const orderid =req.params.orderid
  const bearertoken = req.headers.authorization.split(" ")[1];

    User.findOneAndUpdate({"bearertoken":bearertoken ,"order._id":orderid   }, 
    { $set:{"order.$.order":false}  },{ },async function(err, users) {
      if(err)
      return await res.json(JSON.parse('{"mesaj":"hata"}'));
      else
      return await res.json(JSON.parse('{"mesaj":"ok"}'));
    });   
 }

 

 module.exports.orderGetAll =async function(req,res){
  const bearertoken = req.headers.authorization.split(" ")[1];

   User.findOne( { "bearertoken":bearertoken },{},{ },async function(err, users) {
    if(err) return await res.json('{"mesaj":"hata"}');  

    if(users===null) { 
      return await res.json(JSON.parse('{"mesaj":"Token Hatalı"}'));
    }
          return  await res.json(users.order);
   } );
 }



module.exports.login=function(req,res){
  console.log(req.body)
        User.findOne({telefon:req.body.telefon,password:req.body.password}, function (err1, user) {
          if (user) {
        console.log(user)
  
            tokens=generateToken(64);
            if ( req.body.remember ) {
              var maxAge_ = 30 * 24 * 3600000;
              res.cookie('token',tokens, { maxAge: maxAge_, httpOnly: true });
            
            } else {
              req.session.cookie.expires = false;
            }  
            const bearertoken = jwt.sign({
              muuid: user._id,
              mrole: user.role,
              memail: user.email,
              mtelefon: user.telefon
              }, 
              secret_key,
              {
                  expiresIn :"365d"
              }
              )
    
            User.updateOne({_id:user._id},{bearertoken:bearertoken,token:tokens},function(err,userss){if(userss){console.log("guncellendi");console.log(userss);
            User.findOne({telefon:req.body.telefon,password:req.body.password}, function (err1, user) {
              if (user) {
            res.json(user)
              }
              })
          
          
          }})
              
          }
          else
          {
            res.json('{"hata":"hatalı bilgi"}')
          }
          
        });
    
  } 
  

module.exports.signup=function(req,res){
    client.get('code',async function(err,result){
      if(result===null)
        {
          await User.find( {
            $or: [{"email":req.body.email},{"telefon":req.body.telefon}]
          },{},{},async function(err, users) {
            console.log(users)
            if(users.length >0) {
              return res.json('{"mesaj":"Email veya Telefon Kullanımda"}');
            }
            else
            {

              const nodemailer = require('nodemailer');
              const transporter = nodemailer.createTransport({
                service: 'gmail',
                auth: {
                  user: 'asiwahilda@gmail.com',
                  pass: 'azloxayaswjfdwaw',
                },
              });
    
              code= Math.floor(Math.random() * (999998 - 100001)) + 100001;
              console.log(code)
    
             await client.setex("code",120,code,(err, reply) => {});
             await  client.setex("name",120,req.body.name,(err, reply) => {});
             await  client.setex("surname",120,req.body.surname,(err, reply) => {});
             await client.setex("email",120,req.body.email,(err, reply) => {});
             await client.setex("telefon",120,req.body.telefon,(err, reply) => {});
             await client.setex("tc",120,req.body.tc,(err, reply) => {});
             await client.setex("password",120,req.body.password,(err, reply) => {});
             console.log("code: "+code);
              /*
             await  transporter.sendMail({
                from: '"Falanca Şirket" <sirketinfo@memet.com>',
                to: req.body.email, 
                subject: "Mesaj basligi",
                html: "<b>doğrulama kodunuz: "+code+"</b>", 
              }).then(info => {
                console.log("code: "+code);
                res.json(JSON.parse('{"mesaj":"Kod Gönderildi"}'));
              }).catch(() => {
                res.json(JSON.parse('{"mesaj":"Kod Atılamadı"}'));
                console.error});
                */
                res.json(JSON.parse('{"mesaj":"Kod Atıldı: '+code+'"}'));
            }
          }) 
       
          
        }
        else
        {
           res.json(JSON.parse('{"mesaj":"Bekleyen Kayıt var"}'));
        }
    })

}

module.exports.verifity=function(req,res){
  client.mget(['code',"name","surname","email","telefon","tc","password"],function(err,result){
  if(req.body.verifity==result[0])
  {

    tokens=generateToken(64);
            var newUser=new User({
              name: result[1],
              surname: result[2],
              email:result[3],
              telefon:result[4],
              tc:result[5],
              password: result[6],
              token: tokens,
              password_link:"",
              role:"user",
              status:true,
            });
   newUser.save(function(err,user){
      if(err)
      {
        console.log(err);
        res.json('{"mesaj":"'+err+'"}');
      }
      else
      {
        const bearertoken = jwt.sign({
          mrole: user.role,
          muuid: user._id,
          memail: user.email,
          mtelefon: user.telefon
          }, 
          secret_key,
          {
              expiresIn :"365d"
          }
          )
        console.log(user)

        User.updateOne({_id:user._id},{bearertoken:bearertoken},function(err,userss){if(userss){console.log("guncellendi");console.log(userss)}})


        /*
        client.flushall((err, success) => {
          if (err) {
            throw new Error(err);
          }
          console.log(success); 
        });
        */
        res.json(JSON.parse('{"mesaj":"basarili","token":"'+tokens+'","bearertoken":"'+bearertoken+'"}'));
      }
   });
 
  }
  else
  {
    
    if(result[0] ===null) res.json(JSON.parse('{"mesaj":"Zaman Aşımı"}'));
    else
    res.json(JSON.parse('{"mesaj":"Beklenmeyen Hata"}'));
  }
  
  })
  
  /*
  Auth.findOne({email:req.session.email},function(err,user){
    if(user)
    {
      console.log(req.body.verifity);
        console.log(user.verifity);
      if(req.body.verifity==user.verifity)
      {
        Auth.updateOne({_id:user._id},{emailOnay:"1"},function(err,user){if(user){console.log("guncellendi")}});
        res.redirect('/control/login');
        req.session.destroy();
      }
      else
      {

      }
    }
  })
  */
}


 
  

module.exports.sorusortek=async function(req,res){ 
  
  const bearertoken = req.headers.authorization.split(" ")[1];
 
  const queryObject = req.body;
  const sorukodu=queryObject.sorukodu;
  const soru=queryObject.soru;
  console.log("veriler alindi")

    User.findOne( {"bearertoken":bearertoken },{},{ },async (err, users)=>  {
    if(err) return res.json(JSON.parse('{"mesaj":"hata"}'))  
    if(users===null) { 
      return res.json(JSON.parse('{"mesaj":"Token Hatalı"}'));
    }
    console.log("girildi")

const prompt = soru;
/*
const prompt =  ` const userSchema = new mongoose.Schema({
          name: { type: String},
          orders: [
            {
              phone: {type: String},
            }], 

           }) 
Nodejs ile yukardaki schema göre orders.phone göre sort sıralaması yaptırıp console.log yazmak`;
*/

      const gptResponse = await openai.createCompletion({
          model: "text-davinci-003",
          prompt: prompt,
          max_tokens: 4000,
          temperature: 0.9,
          top_p:0.9,
          presence_penalty: 0.9,
          frequency_penalty: 0.9,
		    //  stop: [" Human:", " AI:"],

        });
        console.log("basla")
        console.log(gptResponse.data.choices[0].text)
        console.log("bitis")


    cevap=gptResponse.data.choices[0].text;
    let data = {
      "cevap": cevap
    };
    
    var varmi =users.sorutek.findIndex(x => x.sorukodu ===sorukodu);

    if(varmi>-1) 
    {          
           // await  User.findOneAndUpdate({"bearertoken":bearertoken,"sorukodu":sorukodu}, 
          //      { $set:{ sorutek :{soru:soru,cevap:cevap}}  },{upsert:true});
           
    }
    else
    {
      await  User.findOneAndUpdate({"bearertoken":bearertoken}, 
                { $push:{ sorutek :{sorukodu:sorukodu,soru:soru,cevap:cevap}}  },{upsert:true});
    }
     
           res.json(data);
      });

         
   
}




module.exports.sorusor=async function(req,res){ 
  
  const bearertoken = req.headers.authorization.split(" ")[1];
 
  const queryObject = req.body;
  const sorukodu=queryObject.sorukodu;
  const soru=queryObject.soru;
  console.log("veriler alindi")

    User.findOne( {"bearertoken":bearertoken },{},{ },async (err, users)=>  {
    if(err) return res.json(JSON.parse('{"mesaj":"hata"}'))  
    if(users===null) { 
      return res.json(JSON.parse('{"mesaj":"Token Hatalı"}'));
    }
    console.log("girildi")


const prompt = soru;
//const prompt =  `Human: Bana 14K GOLD rengi ROSE boyutu 5 karatı 0.55 ağılığı 3.04,2.92 ile ilgili bir ürünün hakkında müşteri yorumu yazarmısın ürün detaylarını vermeden\n`;


      const gptResponse = await openai.createCompletion({
          model: "text-davinci-003",
          prompt: prompt,
          max_tokens: 1600,
          temperature: 0.9,
          top_p: 1,
          presence_penalty: 0,
          frequency_penalty: 0.5,
		  stop: [" Human:", " AI:"],

        });
        console.log(gptResponse.data.choices[0].text)
 

    yeniSoru=soru + " AI:"+gptResponse.data.choices[0].text;

       var varmi =users.soru.findIndex(x => x.sorukodu ===sorukodu);

       if(varmi>-1) 
       {
        console.log("varsa duzenlenecek")

           await   User.findOneAndUpdate({"bearertoken":bearertoken ,'soru.sorukodu':  sorukodu   }, 
              { $set:{ soru :{soru:yeniSoru,sorukodu:sorukodu}}  },{upsert:true}); 
      }
       else{
        console.log("yeni ekleniyor")
            await  User.findOneAndUpdate({"bearertoken":bearertoken}, 
                { $push:{ soru :{sorukodu:sorukodu,soru:yeniSoru}}  },{upsert:true});
           }  

     
           res.json(users);
      });

         
   
}


module.exports.userGetDetay =async function(req,res){
 // console.log(req.userData)
  var url =req.params.url
  const bearertoken = req.headers.authorization.split(" ")[1];

  User.findOne( {"bearertoken":bearertoken },{},{ },async function(err, users) {
    if(err) return await res.json('{"mesaj":"hata"}');  

    if(users===null) { 
      return await res.json(JSON.parse('{"mesaj":"Token Hatalı"}'));
    }
    let sonuc=[];
    switch(url) {
      case "all":
        sonuc=users;
        break;
      case "symbol":
        sonuc=users.symbol;
        break;
      case "wallet":
          sonuc=users.wallet;
        break;
      case "exchange":
          sonuc=users.exchange;
        break;
      default:
        sonuc=users;
    }
     
    return  await res.json(sonuc);
  
  })
}



module.exports.deleteUserExchange=async function(req,res){ 
    const bearertoken = req.headers.authorization.split(" ")[1];
    const exchangePost=  req.body.exchange
    await User.findOneAndUpdate({"bearertoken":bearertoken}, 
    { $pullAll: { exchange: [exchangePost] }},{upsert:true},
     async function(err, userss) {
      console.log(userss)
         return await res.json(JSON.parse('{"mesaj":"basarili" }'))
    } 
    );
   return res.json(JSON.parse('{"mesaj":"hata var"}'));
}



module.exports.saveUserExchange=async function(req,res){ 
  const bearertoken = req.headers.authorization.split(" ")[1];
  const exchangePost=  req.body.exchange
User.findOne( {"bearertoken":bearertoken },{},{ },async function(err, users) {
  if(err) return res.json(JSON.parse('{"mesaj":"hata"}'))  
  if(users===null) { 
    return res.json(JSON.parse('{"mesaj":"Token Hatalı"}'));
  }

   var varmi = users.exchange.indexOf(exchangePost);
   if(varmi>-1) return res.json(JSON.parse('{"mesaj":"Zaten ekli"}'))

   await User.findOneAndUpdate({"bearertoken":bearertoken}, 
          { $push:{ exchange:exchangePost}  },{upsert:true},
          
           async function(err, userss) {

           await User.findOne({_id:userss._id},async function (err1, user3) {
              if (user3) {
                      // return await res.json(user3)
                 return await res.json(JSON.parse('{"mesaj":"basarili" }'))
              }
              })

          } 
          );
           
        
  


 });

}

 

module.exports.addFavSymbol=async function(req,res){ 

  const bearertoken = req.headers.authorization.split(" ")[1];
  const symbolPost=  req.body.symbol
User.findOne( {"bearertoken":bearertoken },{},{ },async function(err, users) {
  if(err) return res.json(JSON.parse('{"mesaj":"hata"}'))  
  if(users===null) { 
    return res.json(JSON.parse('{"mesaj":"Token Hatalı"}'));
  }


        var varmi =users.symbol.findIndex(x => x.symbol ===symbolPost);
        if(varmi>-1) return res.json(JSON.parse('{"mesaj":"Zaten ekli"}'))

        addHisse.findOne( {"symbol":symbolPost },{},{ },async function(err, hisse) {
          if(err) return res.json(JSON.parse('{"mesaj":"hisse hata"}'))  
          if(hisse===null) { 
            return res.json(JSON.parse('{"mesaj":"hisse Hatalı"}'));
          }
       
      await User.findOneAndUpdate({"bearertoken":bearertoken}, 
        { $push:{ symbol:{symbol:symbolPost,exchange:hisse.exchange}}  },{upsert:true},
        
         async function(err, userss) {
          await User.findOne({_id:userss._id},async function (err1, user3) {
            if (user3) {
                    // return await res.json(user3)
               return await res.json(JSON.parse('{"mesaj":"basarili" }'))
            }
            })
          } 
        );
        
      })
      
 });

}

module.exports.deleteFavSymbol=async function(req,res){ 

  const bearertoken = req.headers.authorization.split(" ")[1];
  const symbolPost=  req.body.symbol
        await User.findOneAndUpdate({"bearertoken":bearertoken}, 
        { $pull: {"symbol":{"symbol":[symbolPost]}}},{upsert:true},
         async function(err, userss) {
               return await res.json(JSON.parse('{"mesaj":"basarili" }'))
        })

}


module.exports.swga=function(req,res){

  res.json(JSON.parse('{"getUser":"Userlari getirir","saveUserExchange":"user icin exchange kaydeder exchange girilir","deleteUserExchange":"user icin exchange siler exchange girilir","addFavSymbol":"user icin Symbol kaydeder symbol girilir","deleteFavSymbol":"user icin Symbol siler  symbol girilir"}'));
 
}

function generateToken(n) {
  var chars = 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789';
  var token = '';
  for(var i = 0; i < n; i++) {
      token += chars[Math.floor(Math.random() * chars.length)];
  }
  return token;
}